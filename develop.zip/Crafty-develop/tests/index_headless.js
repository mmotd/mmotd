Crafty = require('../src/crafty_headless.js')();
Crafty.init();
